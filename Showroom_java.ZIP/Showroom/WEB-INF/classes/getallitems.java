import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.util.*;
import java.sql.*;
import javax.swing.*;

public class getallitems extends HttpServlet {

    public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html");

        PrintWriter out = res.getWriter();
        
        
	
	adminDAO adao = new adminDAO();
    try{
        
        //out.println("<h1>Inventory<h1>");
        
        ResultSet rs = adao.getallbikes();

        while(rs.next())
        {
            try{
                String n = rs.getString("name");
                String p = String.valueOf(rs.getInt("price"));
                out.println("<br><h3>" + n +"</h3><div style=\"border: 1px solid; padding:20px; max-width:500px; margin-left:20px\"><form action=\"cart\" method=\"post\"><input type=\"hidden\" name=\"bike\" value="+n+"><input type=\"hidden\" name=\"price\" value="+p+"><input type=\"number\" name=\"quantity\" placeholder=\"Quantity\"><h5>Price :"+p+"<h5><input type=\"submit\" value=\"Add to Cart\"></form></div>");
        
            }
            catch(Exception e)
            {
                out.println(e);
            }
        }
        
    }
    catch (Exception e)
    {
        out.println(e);
    }

    }
    // public void doGet(HttpServletRequest request, HttpServletResponse response)
    // throws ServletException, IOException {
    // processRequest(request, response);
    // }

    // public void doPost(HttpServletRequest request, HttpServletResponse response)
    // throws ServletException, IOException {
    // processRequest(request, response);
    // }
}
