import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import javax.swing.*;

public class signup extends HttpServlet{

public void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        PersonDAO persondao = new PersonDAO();
        int i = persondao.signup(name,email,password,0);
	
	if(i > 0){
		 
                    response.sendRedirect("login.html");
	}

	else{
		out.println("Error");
                
                response.sendRedirect("signup.html");
	}
	}

// Handles the HTTP GET method.
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException, IOException { 
		processRequest(request, response);} 

// Handles the HTTP POST method 
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException { 
		processRequest(request, response);}
}