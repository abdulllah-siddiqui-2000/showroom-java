import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.util.*;
import java.sql.*;
import javax.swing.*;

public class getallorders extends HttpServlet {

    public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html");

        PrintWriter out = res.getWriter();
        
        
	
	adminDAO adao = new adminDAO();
    try{
        
        //out.println("<h1>Orders<h1>");
        
        ResultSet rs = adao.getallorders();

        
        
        out.println("<table><tr><th>Order Id</th><th>Bike</th><th>Quantity</th><th>Total</th><th>Email</th></tr>");
        while(rs.next())
        {
            try{
                out.println("<tr><th>"+ rs.getInt("orderid") +"</th><th>"+rs.getString("bike")+"</th><th>"+rs.getInt("quantity")+"</th><th>"+rs.getInt("price")+"</th><th>"+rs.getString("email")+"</th></tr>");
        
            }
            catch(Exception e)
            {
                out.println(e);
            }
        }
        out.println("</table>");
    }
    catch (Exception e)
    {
        out.println(e);
    }

    }
    // public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    //     processRequest(request, response);
    // }

    // public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    //     processRequest(request, response);
    // }
}



    