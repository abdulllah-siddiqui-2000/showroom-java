import java.sql.*;

public class adminDAO {
    Connection con = null;
    private static adminDAO adao = new adminDAO();


    public adminDAO() {
        try {
		con = DBconnect.getConnection();
            
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    public static adminDAO getAD() {
        return adao;
    }
    public ResultSet getallorders(){
        ResultSet rs = null;
        try {
            String query1 = "SELECT * from orders";
            PreparedStatement ps = con.prepareStatement(query1);
           
             rs = ps.executeQuery();
            
            return rs;            
        
        }
            catch (Exception e) {
                System.out.println(e);
            }

           
            return rs;
    }

    public ResultSet getallbikes(){
        ResultSet rs = null;
        try {
            String query1 = "SELECT * from bikes";
            PreparedStatement ps = con.prepareStatement(query1);
           
             rs = ps.executeQuery();
            
            return rs;            
        
        }
            catch (Exception e) {
                System.out.println(e);
            }

           
            return rs;
    }



}