import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import javax.swing.*;

public class login extends HttpServlet{

public void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String e = request.getParameter("email");
        String p = request.getParameter("password");

        PersonDAO persondao = new PersonDAO();
        PersonInfo person = persondao.login(e,p);

	if(person != null){
                 
                HttpSession session = request.getSession();

                session.setAttribute("email",person.getPersonEmail());
                session.setAttribute("usertype", person.getUserType());
	     
                if(person.getUserType() == 1){
	
               
                response.sendRedirect("admin.jsp");
                }

                else{
	
                
                response.sendRedirect("cart.jsp");
                }
	}
	else{
		out.println("Email or Password is invalid");
                response.sendRedirect("login.html");
	}
	}

// Handles the HTTP GET method.
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException, IOException { 
		processRequest(request, response);} 

// Handles the HTTP POST method 
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException { 
		processRequest(request, response);}
}