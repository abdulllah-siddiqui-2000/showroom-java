public class PersonInfo { 
    String name;
    String email;
    String password;
    int usertype; 
    
    public PersonInfo(String n, String e, String p, int u) { 
    name = n;
    email = e;
    password = p;
    usertype = u;
    }

    public int getUserType(){
    return usertype ;
    }
    public String getPersonEmail(){
    return email ;
    }




} 
