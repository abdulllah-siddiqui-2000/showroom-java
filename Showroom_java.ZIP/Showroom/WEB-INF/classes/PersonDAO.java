import java.sql.*; 
public class PersonDAO { 
// method searchPerson


 Connection con = null;
    private static PersonDAO pa = new PersonDAO();


    public PersonDAO() {
        try {
		con = DBconnect.getConnection();
            
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    public static PersonDAO getPD() {
        return pa;
    }



  public PersonInfo login(String email, String password){ 
	PersonInfo person = null; 
   try { 

	
	String sql = "SELECT * FROM personinfo WHERE email = ? and password = ?"; 
	PreparedStatement pStmt = con.prepareStatement(sql); 
	pStmt.setString(1, email); 
	pStmt.setString(2, password); 
	ResultSet rs = pStmt.executeQuery(); 
	if (rs.next( ) ) {
		String name = rs.getString("name");
		int usertype = rs.getInt("usertype"); 
		person = new PersonInfo(name, email, password, usertype); 

	} 


	}
    catch(Exception ex){ 
		System.out.println(ex); 
	} 

  return person; 

 }// end method 

  public int signup(String name, String email, String password, int usertype){ 
	int i = 0;
   try { 

	
	String sql = "INSERT INTO personinfo(name, email, password, usertype) values (?,?,?,?)"; 
	PreparedStatement pStmt = con.prepareStatement(sql); 
	pStmt.setString(1, name);
	pStmt.setString(2, email); 
	pStmt.setString(3, password);
	pStmt.setInt(4, usertype); 
	i = pStmt.executeUpdate(); 
	if (i>0 )  { 
			System.out.println("inserted successfully");
	}
	else
	{ 
			System.out.println("Error inserting");
	} 
	
	}
    catch(Exception ex){ 
		System.out.println(ex); 
	} 

return i; 

 }

  public int addperson(String name, String email, String password, int usertype){ 
	int i = 0;
   try { 

	
	String sql = "INSERT INTO personinfo(name, email, password, usertype) values (?,?,?,?)"; 
	PreparedStatement pStmt = con.prepareStatement(sql); 
	pStmt.setString(1, name);
	pStmt.setString(2, email); 
	pStmt.setString(3, password);
	pStmt.setInt(4, usertype); 
	i = pStmt.executeUpdate(); 
	if (i>0 )  { 
			System.out.println("Added successfully");
	}
	else
	{ 
			System.out.println("Error adding");
	} 

	}
    catch(Exception ex){ 
		System.out.println(ex); 
	} 

return i; 

 }



public int delperson(String email){ 
	int i = 0;
   try { 

	
	String sql = "DELETE FROM personinfo WHERE email=?";

	PreparedStatement pStmt = con.prepareStatement(sql); 
	pStmt.setString(1, email); 
	i = pStmt.executeUpdate();
            if(i != 0){	 
			System.out.println("deleted");
	}
	else
	{ 
			System.out.println("Error");
	} 

	}
    catch(Exception ex){ 
		System.out.println(ex); 
	} 

return i; 

 }

}