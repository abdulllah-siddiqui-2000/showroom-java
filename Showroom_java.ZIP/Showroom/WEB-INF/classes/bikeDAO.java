import java.sql.*; 
public class bikeDAO { 
// method add bike 

    Connection con = null;
    private static bikeDAO ma = new bikeDAO();


    public bikeDAO() {
        try {
		con = DBconnect.getConnection();
            
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    public static bikeDAO getOD() {
        return ma;
    }

	

  public int addbikes(String bike, int quantity, int price){ 
	int i = 0;
   try { 

	
	
	String sql = "INSERT INTO bikes(name, quantity, price) values (?,?,?)"; 
	PreparedStatement pStmt = con.prepareStatement(sql); 
	pStmt.setString(1, bike);
	pStmt.setInt(2, quantity); 
	pStmt.setInt(3, price); 
	i = pStmt.executeUpdate(); 
	if (i>0 )  { 
			System.out.println("inserted successfully");
	}
	else
	{ 
			System.out.println("Error inserting");
	} 
	 
	}
    catch(Exception ex){ 
		System.out.println(ex); 
	} 

return i; 

 }
public int delbikes(String bike){ 
	int i = 0;
   try { 

	
	
	String sql = "DELETE FROM bikes WHERE name=?";

	PreparedStatement pStmt = con.prepareStatement(sql); 
	pStmt.setString(1, bike); 
	int  rs = pStmt.executeUpdate();
            if(rs != 0){	 
			System.out.println("deleted");
	}
	else
	{ 
			System.out.println("Error");
	} 
	 
	}
    catch(Exception ex){ 
		System.out.println(ex); 
	} 

return i; 

 }

public int change_quantity(String bike, int quantity){ 
	int i = 0;
   try { 

	
	String sql = "UPDATE bikes SET quantity=? WHERE name=?";

	PreparedStatement pStmt = con.prepareStatement(sql); 
	pStmt.setString(2, bike);
	pStmt.setInt(1, quantity); 
	int  rs = pStmt.executeUpdate();
            if(rs != 0){	 
			System.out.println("changed");
	}
	else
	{ 
			System.out.println("Error");
	} 
	 
	}
    catch(Exception ex){ 
		System.out.println(ex); 
	} 

return i; 

 }

public int change_price(String bike, int price){ 
	int i = 0;
   try { 

	
	
	String sql = "UPDATE bikes SET price=? WHERE name=?";

	PreparedStatement pStmt = con.prepareStatement(sql); 
	pStmt.setString(2, bike);
	pStmt.setInt(1, price); 
	int  rs = pStmt.executeUpdate();
            if(rs != 0){	 
			System.out.println("changed");
	}
	else
	{ 
			System.out.println("Error");
	} 
	 
	}
    catch(Exception ex){ 
		System.out.println(ex); 
	} 

return i; 

 }

}