public class bikeInfo { 
    String bike;
    int quantity;
    int price;
     
    
    public bikeInfo(String m, int q, int p) { 
    bike = m;
    quantity = q;
    price = p;
   
    }


} 
