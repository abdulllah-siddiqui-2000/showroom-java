import java.sql.*;

public class orderDAO {
    Connection con = null;
    private static orderDAO oa = new orderDAO();


    public orderDAO() {
        try {
		con = DBconnect.getConnection();
            
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    public static orderDAO getOD() {
        return oa;
    }

    public int addorder(String bike, int quantity,int price, String email) {
        int rs = 1;

        try {
            String query1 = "INSERT INTO orders(bike, quantity, price, email) VALUES (?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(query1);
            ps.setString(1, bike);
            ps.setInt(2, quantity);
            ps.setInt(3, price);
            ps.setString(4, email);
            rs = ps.executeUpdate();


            query1 = "Select * from bikes where name = ? ";
            ps = con.prepareStatement(query1);
            ps.setString(1, bike);
            ResultSet rs1 = ps.executeQuery();
            int q = 1;
            if (rs1.next()) {
                q = rs1.getInt("quantity");
                q = q - quantity;
            }
            query1 = "UPDATE bikes SET quantity = ?  WHERE name = ? ";
            ps = con.prepareStatement(query1);
            ps.setInt(1, q);
            ps.setString(2, bike);
            ps.executeUpdate();


        } catch (Exception e) {
            System.out.println(e);
        }

        return rs;
    }

public int delorder(int orderid){ 
	int i = 0;
   try { 

	String sql = "DELETE FROM orders WHERE orderid=?";

	PreparedStatement pStmt = con.prepareStatement(sql); 
	pStmt.setInt(1, orderid); 
	i = pStmt.executeUpdate();
            if(i != 0){	 
			System.out.println("deleted");
	}
	else
	{ 
			System.out.println("Error");
	} 
	 
	}
    catch(Exception ex){ 
		System.out.println(ex); 
	} 

return i; 

 }

 public int checkquantity(String bike,int quantity){ 

	
   try { 

	String sql = "select * from bikes where name=?";;

	PreparedStatement pStmt = con.prepareStatement(sql); 
	pStmt.setString(1, bike);
	ResultSet rs  = pStmt.executeQuery();
           rs.next();

           if (quantity <= (rs.getInt("quantity"))) {

            return 1;
        }
	 
	}
    catch(Exception ex){ 
		System.out.println(ex); 
	} 

return 0; 

 }




}