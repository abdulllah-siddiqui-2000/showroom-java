import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.util.*;
import java.sql.*;
import javax.swing.*;

public class delperson extends HttpServlet {
    public void processRequest(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html");

        PrintWriter out = res.getWriter();
        out.println("<html><body");
        out.println("<h1>Cart<h1>");
        String email = req.getParameter("email");

      	PersonDAO persondao = new PersonDAO();
	int i = persondao.delperson(email);
	
            if(i != 0)
            {
                res.sendRedirect("http://localhost:8080/showroom/admin.jsp");
            }
            else{
                out.println("<h1>error</h1>");
            }


      

    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

}
