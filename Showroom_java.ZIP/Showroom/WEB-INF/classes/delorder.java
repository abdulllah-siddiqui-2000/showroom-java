import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.util.*;
import java.sql.*;
import javax.swing.*;

public class delorder extends HttpServlet {
    public void processRequest(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html");

        PrintWriter out = res.getWriter();
        out.println("<html><body");
        out.println("<h1>Cart<h1>");
        int orderid = Integer.parseInt(req.getParameter("orderid"));

       orderDAO orderdao = new orderDAO();
	int i = orderdao.delorder(orderid);
            if(i != 0)
            {
                res.sendRedirect("http://localhost:8080/showroom/admin.jsp");
            }
            else{
                out.println("<h1>Error</h1>");
            }

    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

}
