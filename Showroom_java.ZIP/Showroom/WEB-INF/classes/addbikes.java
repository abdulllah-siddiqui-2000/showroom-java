import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.util.*;
import java.sql.*;
import javax.swing.*;

public class addbikes extends HttpServlet {
    public void processRequest(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html");

        PrintWriter out = res.getWriter();
        out.println("<html><body");
        out.println("<h1>Cart<h1>");
        String bike = req.getParameter("bikename");
        int quantity = Integer.valueOf(req.getParameter("quantity"));
	int price = Integer.valueOf(req.getParameter("price"));
	
	bikeDAO mdao = new bikeDAO();
	int i = mdao.addbikes(bike,quantity,price);

       
            if(i != 0)
            {
                res.sendRedirect("http://localhost:8080/showroom/admin.jsp");
            }
            else{
                out.println("<h1>Error</h1>");
		 res.sendRedirect("http://localhost:8080/showroom/admin.jsp");
            }

    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

}
