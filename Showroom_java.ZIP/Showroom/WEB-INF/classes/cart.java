import java.io.*;
import javax.servlet.http.*;
import java.lang.ProcessBuilder.Redirect;;
import javax.servlet.*;
import java.util.*;
import java.sql.*;
import javax.swing.*;

public class cart extends HttpServlet {
    public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        

        orderDAO oa = orderDAO.getOD();

        String bike = req.getParameter("bike");
        int quanity = Integer.valueOf(req.getParameter("quantity"));
        int price = Integer.valueOf(req.getParameter("price")) * quanity;

        try {
            HttpSession session = req.getSession();
            List<String[]> cartitems = new ArrayList<String[]>();
            if (session.getAttribute("orders") != null) {
                cartitems = (List<String[]>) session.getAttribute("orders");

            }

            int val = 0;
            while (cartitems.size() > val) {

                if ((cartitems.get(val)[0].equals(bike))) {

                    int q = Integer.parseInt(cartitems.get(val)[1]);
                    q = q + quanity;
                    quanity = q;
                    cartitems.remove(val);

                    val = cartitems.size() + 5;
                }
			val = val + 1;
            }
            if(oa.checkquantity(bike, quanity) ==1){

                cartitems.add(new String[] { bike, (Integer.toString(quanity)), (Integer.toString(price)) });
                session.setAttribute("orders", cartitems);
                res.sendRedirect("http://localhost:8080/showroom/cart.jsp");
            }
            else{
                System.out.println("quantity not available!");

            }
            //con.close();

        } catch (Exception e) {
            // out.println(e);
        }
        

    }
}
