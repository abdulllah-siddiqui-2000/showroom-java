import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import javax.swing.*;

public class addperson extends HttpServlet{

public void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
	int usertype = Integer.parseInt(request.getParameter("usertype"));

        PersonDAO persondao = new PersonDAO();
        int i = persondao.addperson(name,email,password,usertype);
	
	if(i > 0){
		 
                    out.println("Added");
		    response.sendRedirect("http://localhost:8080/showroom/admin.jsp");
	}

	else{
		out.println("Error");
                
                
	}
	}

// Handles the HTTP GET method.
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException, IOException { 
		processRequest(request, response);} 

// Handles the HTTP POST method 
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException { 
		processRequest(request, response);}
}